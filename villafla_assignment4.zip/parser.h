#ifndef PARSER_H
#define PARSER_H

#include "smallsh.h"

// The following code implements the sample parser 

struct command_line *parse_input();

#endif
